#include <iostream>
#include <ctime>
#include <cstring>
#include <string>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <fstream>
#include <sys/stat.h>
#include <vector>
#include <queue>
#include <cstdio>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
using namespace std;


struct process{
	int time; // the time when it is inserted into the program(I/O time)
	int priority;
	int pid; // Process ID
	int inst_num; // Instruction Number
	int line = 1; // for scheduler.txt file.
	
	char code_name[100];
	queue<int> opcode;
	queue<int> argument;
	
	//======MEMORY======//
	
	int pageCount = 0; // used to allocate new page's ID
	int referByte[1000] = {0}; // store each pageID's reference Byte 
	
	int pageID[1000] = {-1}; //PID
	int alloID[1000] = {-1}; //AID
	int validBit[1000] = {-1}; //ValibBit
	int referenceBit[1000] = {-1}; //Ref
	

};


int main(int argc, char* argv[])
{
    char *dir;
    char *page;
    
    char a[] = "lru";
    page = strtok(a," ");  // default page replacement algorithm(=lru)
    
    int pageNum = 0; // store the data VMsize/Page_size
    int physNum = 0; // store the data PMsize/Page_size
    int presentMem[100] = {0}; // show which PageID is used in Physical Memory, 1 = Using, 0 = Not using.
    int total_num =0; // total process ID's number
    int page_fault = 0; // For "memory.txt", number of page_fault
    int alloCount = 0; // For AID's allocation number
    int cur_opcode, cur_argument; // current_opcode's and current argument's stored data
    int clock =0;
    queue<int> LRU; // if algorithm is "LRU", use the queue to choose which one is appropriate.
    char aaa[1000]; // for defalt directory.
    getcwd(aaa,1000);
    dir = strtok(aaa, " "); // default directory(=current directory)
    for(int i=1;i<argc;i++){ // if there is other option(-page, -dir), the data is stored at each position.
        //cout << argv[i] << endl;
        char* token = strtok(argv[i],"=");
        if(strcmp(token,"-page")==0){
            page = strtok(NULL," "); // page option 
            
        }
        else if(strcmp(token,"-dir")==0){
            dir = strtok(NULL," "); // dir option    
        }
        

    }
    
    
    char input_dir[1000];
    strcpy(input_dir,dir);
    char input_text[20] = "/input"; // directory's input text directory.
    strcat(input_dir,input_text); // concatenate dir and "/input" -> dir/input
    std::ifstream readFile;
    readFile.open(input_dir); // file read.
    if(readFile.is_open()){
        char arr[256];
        readFile.getline(arr,256);
        total_num = atoi(strtok(arr," ")); // 1 Line : Store the data
        int VM_size = atoi(strtok(NULL," "));
        int PM_size = atoi(strtok(NULL," "));
        int Page_size = atoi(strtok(NULL," "));
	pageNum = VM_size/Page_size;
	physNum = PM_size/Page_size;
        int current_num = 0;
        int input_time[10] = {0};
        struct process pid[total_num];
        
        int physMem[physNum] = {0};
        int physMemPID[physNum] = {0};
	
        for(int i=0;i<physNum;i++){ // Init
        	physMem[i] = -1;
        	physMemPID[i] = -1;
        }
        for(int j=0;j<total_num;j++){ // Init
		for(int i=0;i<pageNum;i++){
			pid[j].pageID[i] = -1;
			pid[j].alloID[i] = -1;
			pid[j].validBit[i] = -1;
			pid[j].referenceBit[i] = -1;
		}
	}
	
        
        
        for(int i=0;i<total_num;i++){ // "Input" File's instruction.
            readFile.getline(arr,256);
            //cout << arr << endl;
            int time = atoi(strtok(arr," "));
            pid[current_num].time = time; // store the time data
            pid[current_num].pid = current_num; // current_num is used to "Process ID"
            char* code = strtok(NULL," ");
            strcpy(pid[current_num].code_name,code);
            const char* IOstring = "INPUT";
            if(strcmp(code,IOstring)==0){ // If second word is "INPUT", save the data in input_time array.
                int PID = atoi(strtok(NULL," "));
                input_time[PID] = time;
                //cout << "PID : "<< PID << endl;
            }
            else{ // if second word is not "INPUT", make process.
                int priority = atoi(strtok(NULL," "));
                pid[current_num].priority = priority;
                char code_dir[1000];
                strcpy(code_dir,dir);
                char add[2] = "/";
                strcat(code_dir,add);
                strcat(code_dir,code);
                
                // Code_dir is the directory of new process.
                
                std::ifstream readFile2;
                readFile2.open(code_dir);
                if(readFile2.is_open()){
                	char arr2[256];
                	readFile2.getline(arr2,256);
                	int inst_num = atoi(strtok(arr2," "));
                	pid[current_num].inst_num = inst_num; // store a prcoess's instruction number. 
                	
                	for(int i=0;i<inst_num;i++){ // insert the opcode, argument in each queue.
                		readFile2.getline(arr2,256);
                		int opcode = atoi(strtok(arr2," "));
                		int argument = atoi(strtok(NULL," "));
                		pid[current_num].opcode.push(opcode);
      	                	pid[current_num].argument.push(argument);
                	}
                }
                readFile2.close();             
                current_num++;
            }
            
        }
        
        int cycle = 0; // Cycle initialization.
        int end; // All instructions number(=process's total instruction number) 
        int current_pid = -1; // store the Current Process ID.
        queue<int> ready_queue[10];
        queue<int> sleep_queue[10];
        queue<int> wait_queue[10];
        int quantum = 10; // If algorithm is "sampled", use a quantum.
        
        chdir(dir); // To make a file in suggested directory, change a directory and make output files in that directory. 
        FILE *out;
	out = fopen("./scheduler.txt", "wt+");
	FILE *out2;
	out2 = fopen("./memory.txt", "wt+");
        while(true){ // Cycle is increasing until end(total instruction number) == 0
        	
        	cur_opcode = -1;
        	end = 0;
        	bool scheduled = false;
        	
        	for(int i=0;i<10;i++){ // check whether process' Sleep is 0 or not.
        		if(!sleep_queue[i].empty()){
				int time_temp = sleep_queue[i].front();
				if(time_temp > 0){
					time_temp--;
				}
				sleep_queue[i].pop();
				sleep_queue[i].push(time_temp);
				if(time_temp ==0){
					sleep_queue[i].pop();
					ready_queue[pid[i].priority].push(pid[i].pid);
				}
			}
        	
        	}
		
		for(int i=0;i<10;i++){ //if IO is called, send a waited process to ready_queue
			if(cycle == input_time[i]){
				if(!wait_queue[i].empty()){
					
					wait_queue[i].pop();
					ready_queue[pid[i].priority].push(pid[i].pid);
				}
			}
		}
		if(current_pid != -1){ //if current_pid's instruction number is 0, release the physical memory which pid is current_pid.
			if(pid[current_pid].opcode.empty()){
				presentMem[pid[current_pid].pid] = 0;
				for(int i=0;i<physNum;i++){
					if(physMemPID[i]==pid[current_pid].pid){
						physMemPID[i] = -1;
						physMem[i] = -1;
					}
				}
				
				current_pid = -1;
				quantum = 10;
				
			}
		}
		for(int i=0;i<current_num;i++){ // if prcoess's input time is equal to cycle, process is pushed to ready queue.
			if(cycle == pid[i].time){ 
				for(int j=0;j<pageNum;j++){
						pid[i].referenceBit[j] = 0; 
				}
				ready_queue[pid[i].priority].push(pid[i].pid);
				presentMem[pid[i].pid] = 1;
			}
		}
		
			 
		if(current_pid == -1){ // Set the value of current process's pid.
			for(int i=0; i<10; i++){
				if(!ready_queue[i].empty()){
					current_pid = ready_queue[i].front();
					ready_queue[i].pop();
					scheduled = true;
				}
			}
			
		}
		else{
			for(int i=0;i<10;i++){
				if(!ready_queue[i].empty()){
					if(pid[current_pid].priority > i){
						ready_queue[i].pop();
						current_pid = i;
						scheduled = true;
					}
				}
				else if(pid[current_pid].priority <= i){
					
				}	
			}	
		}

		
		if(strcmp(page,"sampled")==0){ // If algorithm is "sampled", reference Bit is updated per 8 cycles.
			if(cycle % 8 ==0){
				
				for(int i=0;i<current_num;i++){
					if(presentMem[i] == 1){
						int tempo = -1;
						for(int j=0;j<pageNum;j++){
							if(pid[i].pageID[j] != -1){
								if(tempo != pid[i].pageID[j]){ // reference Byte is updated at the front of reference Byte.
									pid[i].referByte[pid[i].pageID[j]] = (pid[i].referByte[pid[i].pageID[j]] / 10) + pid[i].referenceBit[j]*10000000;
									
								}
								tempo = pid[i].pageID[j]; // if any pageID is updated, set the value of tempo to pageID and ensure that reference Byte is updated only once.
							}
						}
					}
				
				}
				for(int i=0;i<current_num;i++){ // set the referenceBit of all processes to 0
					if(presentMem[i] == 1){
						for(int j=0;j<pageNum;j++){
							pid[i].referenceBit[j] = 0;
						}
					}
				}
				
			}
		}
		
		
		
		
		
		//=============================== PRINT====================================//
		
		fprintf(out, "[%d Cycle] Scheduled Process: ", cycle);
		if(scheduled){ // if current program exists, print the priority and process name.
			fprintf(out, "%d %s (priority %d)\n", current_pid, pid[current_pid].code_name, pid[current_pid].priority);
		}
		else{
			fprintf(out, "None\n");
		}
		fprintf(out, "Running Process: ");
		if(current_pid != -1){ // if current_pid is exist, run the instruction code.
			if(!pid[current_pid].opcode.empty()){
				fprintf(out, "Process#%d(%d) running code %s line %d(op %d, arg %d)\n",pid[current_pid].pid, pid[current_pid].priority,pid[current_pid].code_name,pid[current_pid].line,pid[current_pid].opcode.front(),pid[current_pid].argument.front());
				if(5<=pid[current_pid].priority && pid[current_pid].priority<=9){ // If current_pid's priority is 5-9, quantum is decreased by 1.
					if(quantum !=0){
						quantum--;
					}
				}
				
				if(quantum ==0){ // if quantum is 0, push the current_pid's pageID in ready_queue, and at the end of the cycle, set the current_pid to -1 
					
					ready_queue[pid[current_pid].priority].push(pid[current_pid].pid);
					//current_pid = -1;
				}	
				cur_opcode = pid[current_pid].opcode.front();
				
				cur_argument = pid[current_pid].argument.front();
				if(pid[current_pid].opcode.front() == 0){ // Page allocation
					bool added = false;
					int count = pid[current_pid].argument.front(); // page's number.
					for(int i=0;i<pageNum;i++){
						if(pid[current_pid].pageID[i] == -1){
							if(count >0){ // if count is up to 0, allocation is executed.
								added = true;
								pid[current_pid].pageID[i] = pid[current_pid].pageCount;
								pid[current_pid].validBit[i] = 0;
								count--;
							}
							
						}
					}					
					if(added == true){ // If allocation is excuted, pageID is increased by 1.
						pid[current_pid].pageCount++;
					}
					pid[current_pid].opcode.pop();
					pid[current_pid].argument.pop();
					pid[current_pid].line++;
				}
				
				else if(pid[current_pid].opcode.front() == 1){ // Page Access
				
					if(strcmp(page,"lru")==0){ // Page algorithm = "lru"
						int cnt = 0, startidx = 0;
						bool alloBool = false;
						for(int i=0;i<pageNum;i++){ // search argument(=PageID) in pageID array, and store the start value and count the number of pid. 
							if(pid[current_pid].pageID[i]==pid[current_pid].argument.front()){
								if(startidx ==0){
									startidx = i;
								}
								cnt++;	
								if(pid[current_pid].alloID[i] == -1){ // if access was not executed, assign AID.
									alloBool = true;
									pid[current_pid].alloID[i] = alloCount;
								}
								
								
							}
						}
						if(alloBool){ // if access is executed, AID number is increased.
							alloCount++;
						}
						int half = physNum;
						
						while(cnt < (half/2)){ // Find the value of physical Memory's size which is 2^n
							half = half/2;
						}
						if(cnt ==0){ half = 0;} // If count is 0(=pageId is not found in pageID array, set the "half" to 0.
						bool empty = true;
						bool pagefault = true;
						bool insert = true;

						if(half!=0){ // if size is found, access is executed.
							for(int i=0;i<physNum;i++){ // if pid was found in physical Memory, access isn't executed.
								if(pid[current_pid].alloID[startidx] == physMem[i]){
									insert = false;
									pagefault = false;
								}
							}
							while(insert){ // If pid was not found in physical memory, insert in physical memory.
								
								for(int i=0;i<physNum;i=i+half){
									empty = true;
									
									for(int a=i;a<(i+half);a++){ // Check whether Physical memory's vacant size is the size of "half". 
										
										if(physMem[a] != -1){
											empty = false;
										}
									}
									if(empty){ // if vacant size is enough, set the physical memory to PageID 
										insert = false;
										
										LRU.push(pid[current_pid].alloID[startidx]); // push the AID in LRU queue.
										for(int j=0;j<half;j++){
											physMem[i+j] = pid[current_pid].alloID[startidx];	
											physMemPID[i+j] = pid[current_pid].pid;
										}
										for(int k=0;k<pageNum;k++){
											if(pid[current_pid].pageID[k] == pid[current_pid].argument.front()){
											
											pid[current_pid].validBit[k] = 1;
											}
										}
										i = physNum;	
											
									}
								}
								if(insert){ // if vacant size is not enough, page replacement is executed.
									for(int i=0;i<physNum;i++){ // If LRU's first value is in physical memory, all of them are removed.  
										if(physMem[i] == LRU.front()){ 
											physMem[i] = -1;
											physMemPID[i] = -1;
										}
									}
									
									for(int i=0;i<pageNum;i++){ // If AID == pageID's AID, set the validBit to 0.
										
										if(pid[current_pid].alloID[i] == LRU.front()){
											pid[current_pid].validBit[i] = 0;
										}
									}
									
									pagefault = false; // Page fault has happend.								
									LRU.pop();
									
								}
							}
							
							
						}

						if(pagefault == false){ // if pagefault happened, increase a page_fault number.
							page_fault++;
						}
						//pop a queue and
						pid[current_pid].opcode.pop(); 
						pid[current_pid].argument.pop();
						pid[current_pid].line++;
					}
					else if(strcmp(page,"sampled")==0){ // Like "LRU", except for [while(insert)] part, all the things are same.
						
						int cnt = 0, startidx = 0;
						bool alloBool = false;
						for(int i=0;i<pageNum;i++){
							if(pid[current_pid].pageID[i]==pid[current_pid].argument.front()){
								if(startidx ==0){
									startidx = i;
								}
								cnt++;	
								if(pid[current_pid].alloID[i] == -1){
									alloBool = true;
									pid[current_pid].alloID[i] = alloCount;
								}
								
								
							}
						}
						if(alloBool){
							alloCount++;
						}
						int half = physNum;
						
						while(cnt < (half/2)){
							half = half/2;
							
						}
						if(cnt ==0){ half = 0;}
						//cout << "cnt :" << cnt << endl;
						//cout << cycle << " half : " << half << endl;
						bool empty = true;
						bool pagefault = true;
						bool insert = true;

						if(half!=0){
							for(int i=0;i<physNum;i++){
								if(pid[current_pid].alloID[startidx] == physMem[i]){
									insert = false;
									pagefault = false;
								}
							}
							while(insert){
								
								for(int i=0;i<physNum;i=i+half){
									empty = true;
									
									for(int a=i;a<(i+half);a++){
										
										if(physMem[a] != -1){
											empty = false;
										}
									}
									if(empty){
										insert = false;
										
										LRU.push(pid[current_pid].alloID[startidx]);
										for(int j=0;j<half;j++){
											physMem[i+j] = pid[current_pid].alloID[startidx];	
											physMemPID[i+j] = pid[current_pid].pid;
										}
										for(int k=0;k<pageNum;k++){
											if(pid[current_pid].pageID[k] == pid[current_pid].argument.front()){
											pid[current_pid].referenceBit[k] = 1;
											pid[current_pid].validBit[k] = 1;
											}
										}
										i = physNum;	
											
									}
								}
								if(insert){ // Changed Part.
									
									int least = 100000000; // Because maximum of reference Byte value is 11111111, set the value to 100000000
									int least_pid = -1; // initialization
									for(int i=0;i<pid[current_pid].pageCount;i++){
										bool checking = false;
										
										if(pid[current_pid].referByte[i] <least){ // find the least reference Byte.
											int what;
											for(int a=0;a<pageNum;a++){
												if(pid[current_pid].pageID[a]==i){
													what = a;
												}
											}
											
											for(int b=0;b<physNum;b++){
												
												if(physMem[b] == pid[current_pid].alloID[what] && pid[current_pid].alloID[what] != -1){
												checking = true;
												
												}
											}
											if(checking){
												least = pid[current_pid].referByte[i];
												least_pid = i;
											}
											
																						
										}
										
									}
									int least_allo = -1;
									for(int i=0;i<pageNum;i++){ // find the AID which pid's reference Byte is least reference Byte.
										
										if(pid[current_pid].pageID[i] == least_pid){
											least_allo = pid[current_pid].alloID[i];
										}
									}
									for(int i=0;i<physNum;i++){ // If AID is in physical Memory, remove the data. 
										if(physMem[i] == least_allo){
											physMem[i] = -1;
											physMemPID[i] = -1;
										}
									}
									
									for(int i=0;i<pageNum;i++){ // IF selected AID is PageID's AID, set the valid, reference Bit to 0.
										
										if(pid[current_pid].alloID[i] == least_allo){
											pid[current_pid].validBit[i] = 0;
											pid[current_pid].referenceBit[i] = 0;
										}
									}
									
									pagefault = false;								
									
								}
							}
							
							
						}

						if(pagefault == false){
							page_fault++;
						}
						pid[current_pid].opcode.pop();
						pid[current_pid].argument.pop();
						pid[current_pid].line++;
					}
					
					else if(strcmp(page,"clock")==0){ //Like "LRU", except for [while(insert)] part, all the things are same.
						
						int cnt = 0, startidx = 0;
						bool alloBool = false;
						for(int i=0;i<pageNum;i++){
							if(pid[current_pid].pageID[i]==pid[current_pid].argument.front()){
								if(startidx ==0){
									startidx = i;
								}
								cnt++;	
								if(pid[current_pid].alloID[i] == -1){
									alloBool = true;
									pid[current_pid].alloID[i] = alloCount;
								}
								
								
							}
						}
						if(alloBool){
							alloCount++;
						}
						int half = physNum;
						
						while(cnt < (half/2)){
							half = half/2;
							
						}
						if(cnt ==0){ half = 0;}
						//cout << "cnt :" << cnt << endl;
						//cout << cycle << " half : " << half << endl;
						bool empty = true;
						bool pagefault = true;
						bool insert = true;

						if(half!=0){
							for(int i=0;i<physNum;i++){
								if(pid[current_pid].alloID[startidx] == physMem[i]){
									insert = false;
									pagefault = false;
								}
							}
							while(insert){
								
								for(int i=0;i<physNum;i=i+half){
									empty = true;
									
									for(int a=i;a<(i+half);a++){
										
										if(physMem[a] != -1){
											empty = false;
										}
									}
									if(empty){
										insert = false;
										
										LRU.push(pid[current_pid].alloID[startidx]);
										for(int j=0;j<half;j++){
											physMem[i+j] = pid[current_pid].alloID[startidx];	
											physMemPID[i+j] = pid[current_pid].pid;
										}
										for(int k=0;k<pageNum;k++){
											if(pid[current_pid].pageID[k] == pid[current_pid].argument.front()){
											pid[current_pid].referenceBit[k] = 1;
											pid[current_pid].validBit[k] = 1;
											}
										}
										i = physNum;	
											
									}
								}
								if(insert){
									int least_pid = -1;
									while(least_pid == -1){ //Find the least_pid using "clock algorithm" 
										for(int i=0;i<pageNum;i++){
											if(pid[current_pid].validBit[i] == 1 && pid[current_pid].pageID[i] == (clock%pid[current_pid].pageCount)){
												if(pid[current_pid].referenceBit[i] == 1){
													pid[current_pid].referenceBit[i] = 0; // Second chance
												}
												
												else if(pid[current_pid].referenceBit[i] == 0){
													least_pid = pid[current_pid].pageID[i];
												}
											}
										}
										clock++;
									}
									
									
									int least_allo = -1;
									for(int i=0;i<pageNum;i++){ // find least pid's AID.
										
										if(pid[current_pid].pageID[i] == least_pid){
											least_allo = pid[current_pid].alloID[i];
										}
									}
									
									for(int i=0;i<physNum;i++){ // same as above.
										if(physMem[i] == least_allo){
											physMem[i] = -1;
											physMemPID[i] = -1;
										}
									}
									
									for(int i=0;i<pageNum;i++){ // same as above.
										
										if(pid[current_pid].alloID[i] == least_allo){
											pid[current_pid].validBit[i] = 0;
											pid[current_pid].referenceBit[i] = 0;
										}
									}
									
									pagefault = false;								
									
								}
							}
							
							
						}

						if(pagefault == false){
							page_fault++;
						}
						pid[current_pid].opcode.pop();
						pid[current_pid].argument.pop();
						pid[current_pid].line++;
					}
					
				}
				
				else if(pid[current_pid].opcode.front() == 2){ // Page Release
					int dest;
					for(int i=0;i<pageNum;i++){ // Find PageID's AID.
						if(pid[current_pid].pageID[i] == pid[current_pid].argument.front()){
							dest = pid[current_pid].alloID[i];	
						}
					}
					
					for(int i=0;i<physNum;i++){ // Release the selected AID in physical memory. 
						if(physMem[i] == dest){
							physMem[i] = -1;
						}
					}
					for(int i=0;i<pageNum;i++){ // Release the selected PID in virtual memory.
						if( pid[current_pid].pageID[i] == pid[current_pid].argument.front()){
							pid[current_pid].pageID[i] = -1;
							pid[current_pid].alloID[i] = -1;
							pid[current_pid].validBit[i] = -1;
							pid[current_pid].referenceBit[i] = -1;
						}
					}
					pid[current_pid].opcode.pop();
					pid[current_pid].argument.pop();
					pid[current_pid].line++;
				}
				else if(pid[current_pid].opcode.front() == 4){ // If opcode is 4, push the current pid to sleep_queue.
					end = 0;
					for(int i=0;i<current_num;i++){
						end += pid[i].opcode.size();
					}
					if(end==1){
						pid[current_pid].opcode.pop();
						pid[current_pid].argument.pop();
						pid[current_pid].line++;
						quantum = 10;
						current_pid = -1;
					}
					else{
						sleep_queue[current_pid].push(pid[current_pid].argument.front());
						pid[current_pid].opcode.pop();
						pid[current_pid].argument.pop();
						pid[current_pid].line++;
						quantum = 10;
						current_pid = -1;
					}
				}
				else if(pid[current_pid].opcode.front() == 5){ // If opcode is 4, push the current pid to wait_queue.
					end = 0;
					for(int i=0;i<current_num;i++){
						end += pid[i].opcode.size();
					}
					if(end==1){
						pid[current_pid].opcode.pop();
						pid[current_pid].argument.pop();
						pid[current_pid].line++;
						quantum = 10;
						current_pid = -1;
					}
					wait_queue[current_pid].push(1);
					pid[current_pid].opcode.pop();
					pid[current_pid].argument.pop();
					pid[current_pid].line++;
					quantum = 10;
					current_pid = -1;
				}
				else{
					pid[current_pid].opcode.pop();
					pid[current_pid].argument.pop();
					pid[current_pid].line++;
				}
				
				if(quantum ==0){
					quantum = 10;
					current_pid = -1;
				}	
				
			}
		}
		
		
		
		else if(current_pid == -1){
			fprintf(out, "None\n");
		}
		for(int i=0;i<10;i++){ // ReadyQueue Print
			fprintf(out, "RunQueue %d: ", i);
			if(ready_queue[i].empty()){
				fprintf(out, "Empty");		
			}
			else{
				for(int j=0;j<ready_queue[i].size();j++){
					int temp;
					temp = ready_queue[i].front();
					ready_queue[i].pop();
					fprintf(out, "%d(%s) ", temp,pid[temp].code_name);
					ready_queue[i].push(temp);
				}
			}
			fprintf(out, "\n");
		}
		
		bool sleep = false;
		for(int i=0;i<10;i++){ // all sleep_queue's time <- 1 decrement.
			if(!sleep_queue[i].empty()){
				sleep = true;
			}
		}
		
		fprintf(out, "SleepList: "); // Print Sleep Queue.
		if(sleep){
		
			for(int i=0;i<10;i++){
				if(!sleep_queue[i].empty()){
					fprintf(out, "%d(%s) ",i, pid[i].code_name);
				}
			}

		}
		else{
			fprintf(out, "Empty");
		}
		
		fprintf(out, "\n");
		
		fprintf(out, "IOWait List: "); // Print IO wait List.
		bool waitOK = false;
		for(int i=0;i<10;i++){
			if(!wait_queue[i].empty()){
				fprintf(out, "%d(%s) ", i, pid[i].code_name);
				waitOK = true;
			}
			else{
			
			}
		}
		if(!waitOK){
			fprintf(out, "Empty");		
		}
		fprintf(out, "\n");
		

		fprintf(out, "\n");
		


		//=======================memory.txt==========================/ 
		string func;
		char func_char[12];
		if(cur_opcode==0){ // set the opcode's name in func.
			func = "ALLOCATION";
		
		}
		else if(cur_opcode==1){
			func = "ACCESS";
		
		}
		else if(cur_opcode==2){
			func = "RELEASE";
		
		}
		else if(cur_opcode==3){
			func = "NON-MEMORY";		
		}
		else if(cur_opcode==4){
			func = "SLEEP";	
		}
		else if(cur_opcode==5){
			func = "IOWAIT";	
		}
		
		int pagen = 0;
		int pageI = 0;
		
		if(cur_opcode != -1){ // Print as each opcode's method. ex) [0 Cycle] ~~
			if(cur_opcode<=2){
				if(cur_opcode == 0){
					pagen = cur_argument; // page Number.
					pageI = pid[current_pid].pageCount-1; // page ID.
				}
				else{
					pageI = cur_argument;
					for(int i=0;i<pageNum;i++){
						if(pid[current_pid].pageID[i] == cur_argument){
							pagen++;
						}
					}
				}
				fprintf(out2, "[%d Cycle] Input: Pid[%d] Function[%s] Page ID[%d] Page Num[%d]\n", cycle, pid[current_pid].pid,func.c_str(),pageI,pagen);
			
			}
			
			else if(cur_opcode ==3){
				fprintf(out2, "[%d Cycle] Input: Pid[%d] Function[%s]\n", cycle, pid[current_pid].pid,func.c_str());
			}
			
			else if(cur_opcode ==4){
				fprintf(out2, "[%d Cycle] Input: Pid[%d] Function[%s]\n", cycle, pid[current_pid].pid,func.c_str());
			}
			else if(cur_opcode ==5){
				fprintf(out2, "[%d Cycle] Input: Pid[%d] Function[%s]\n", cycle, pid[current_pid].pid,func.c_str());
			}
		}
		else{
			fprintf(out2, "[%d Cycle] Input: Function[NO-OP]\n", cycle);
		}
		
		fprintf(out2,"%-30s", ">> Physical Memory: "); // Print the physical memory.
		for(int i=0;i<physNum;i++){
			if(i%4==0){ fprintf(out2, "|");}
			if(physMem[i] != -1){
				fprintf(out2,"%d",physMem[i]);
			}
			else{
				fprintf(out2,"%s","-");
			}
			
			
		}
		fprintf(out2, "|\n");
		
		for(int j=0;j<total_num;j++){ // Print PID,AID,validBit,ref.
			if(presentMem[j] ==1){ // If process is not end, print them.
				fprintf(out2,">> pid(%d) %-20s", j, " Page Table(PID): ");
				for(int i=0;i<pageNum;i++){
					if(i%4==0){ fprintf(out2, "|");}
					if(pid[j].pageID[i] != -1){
						fprintf(out2,"%d",pid[j].pageID[i]);
					}
					else{
						fprintf(out2,"%s","-");
					}
					
					
				}
				fprintf(out2, "|\n");
				
				fprintf(out2,">> pid(%d) %-20s", j, " Page Table(AID): ");
				for(int i=0;i<pageNum;i++){
					if(i%4==0){ fprintf(out2, "|");}
					if(pid[j].alloID[i] != -1){
						fprintf(out2,"%d",pid[j].alloID[i]);
					}
					else{
						fprintf(out2,"%s","-");
					}
					
					
				}
				fprintf(out2, "|\n");
				
				fprintf(out2,">> pid(%d) %-20s", j, " Page Table(Valid): ");
				for(int i=0;i<pageNum;i++){
					if(i%4==0){ fprintf(out2, "|");}
					if(pid[j].validBit[i] != -1){
						fprintf(out2,"%d",pid[j].validBit[i]);
					}
					else{
						fprintf(out2,"%s","-");
					}
					
					
				}
				fprintf(out2, "|\n");
				
				fprintf(out2,">> pid(%d) %-20s", j, " Page Table(Ref): ");
				for(int i=0;i<pageNum;i++){
					if(i%4==0){ fprintf(out2, "|");}
					if(pid[j].referenceBit[i] != -1){
						fprintf(out2,"%d",pid[j].referenceBit[i]);
					}
					else{
						fprintf(out2,"%s","-");
					}
					
					
				}
				fprintf(out2, "|\n");
			}
		}
		fprintf(out2, "\n");
		end = 0;
		for(int i=0;i<current_num;i++){
			end += pid[i].opcode.size();
		}
		if(end ==0){
			break;
		}
		
		
		cycle++;
        }
        fprintf(out2, "page fault = %d\n", page_fault);
        fclose(out);
        fclose(out2);
        
    }
    readFile.close();
    return 0;
}
